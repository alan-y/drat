# phstemplates 0.9.0

* PHS template for RStudio 1.2.
* Fixed gitignore for Excel files

# phstemplates 0.8.3

* Changes required for change to PHS.

# phstemplates 0.8.2

* Renamed project function to `phsproject()` in preparation for package name change.
* Better error checking of filepaths for the RStudio 1.2 HPS report template.

# phstemplates 0.8.1

* Option to initialise new project with Git enabled.
* RStudio addin to add new R script based on the template.

# phstemplates 0.8.0

* Start new project with more than one code file.
* Added RMarkdown templates for ISD national stats reports and summaries.
