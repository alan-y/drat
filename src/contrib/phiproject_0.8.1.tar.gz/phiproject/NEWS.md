# phiproject 0.8.1

* Option to initialise new phiproject with Git enabled.
* RStudio addin to add new R script based on the phiproject template.

# phiproject 0.8.0

* Start new phiproject with more than one code file.
* Added RMarkdown templates for ISD national stats reports and summaries.
